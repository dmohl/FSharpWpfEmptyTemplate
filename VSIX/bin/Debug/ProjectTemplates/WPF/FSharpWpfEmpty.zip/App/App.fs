﻿module MainApp

open System
open System.Windows
open System.Windows.Controls
open FSharpx

type MainWindow = XamlFile<"MainWindow.xaml">

let loadWindow() =
   let window = MainWindow()
   
   // Your awesome code code here and you have strongly typed access to the XAML via "window"
   
   window.Control

[<STAThread>]
(new Application()).Run(loadWindow()) |> ignore